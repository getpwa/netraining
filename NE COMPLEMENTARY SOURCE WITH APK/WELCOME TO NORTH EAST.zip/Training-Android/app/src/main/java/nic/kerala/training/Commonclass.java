package nic.kerala.training;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.android.volley.toolbox.HurlStack;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.Certificate;
import java.security.cert.CertificateException;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.SSLSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.TrustManagerFactory;
import javax.net.ssl.X509TrustManager;

/**
 * Created by asg4.dev13 on 7/11/2017.
 */

public class Commonclass {

    static Context context;
    private static Activity activity;

    public Commonclass(Context con) {
        context = con;
        activity = (Activity) con;
    }



    public static HostnameVerifier getHostnameVerifier() {
        return new HostnameVerifier() {
            @Override
            public boolean verify(String hostname, SSLSession session) {


                HostnameVerifier hv = HttpsURLConnection.getDefaultHostnameVerifier();

                return true;
            }
        };
    }

    private static TrustManager[] getWrappedTrustManagers(TrustManager[] trustManagers) {
        final X509TrustManager originalTrustManager = (X509TrustManager) trustManagers[0];
        return new TrustManager[]{
                new X509TrustManager() {
                    public X509Certificate[] getAcceptedIssuers() {
                        return originalTrustManager.getAcceptedIssuers();
                    }

                    public void checkClientTrusted(X509Certificate[] certs, String authType) {
                        try {
                            if (certs != null && certs.length > 0) {
                                certs[0].checkValidity();
                            } else {
                                originalTrustManager.checkClientTrusted(certs, authType);
                            }
                        } catch (CertificateException e) {
                            Log.w("checkClientTrusted", e.toString());
                        }
                    }

                    public void checkServerTrusted(X509Certificate[] certs, String authType) {
                        try {
                            if (certs != null && certs.length > 0) {
                                certs[0].checkValidity();
                            } else {
                                originalTrustManager.checkServerTrusted(certs, authType);
                            }
                        } catch (CertificateException e) {
                            Log.w("checkServerTrusted", e.toString());
                        }
                    }
                }
        };
    }
    public static SSLSocketFactory getSSLSocketFactorys()
            throws CertificateException, KeyStoreException, IOException, NoSuchAlgorithmException, KeyManagementException {



// creating a KeyStore containing our trusted CAs
        String keyStoreType =KeyStore.getDefaultType();
        KeyStore keyStore =KeyStore.getInstance(keyStoreType);
        keyStore.load(null,null);

        // creating a TrustManager that trusts the CAs in our KeyStore
        String tmfAlgorithm =TrustManagerFactory.getDefaultAlgorithm();
        TrustManagerFactory tmf =TrustManagerFactory.getInstance(tmfAlgorithm);
        tmf.init(keyStore);

        // creating an SSLSocketFactory that uses our TrustManager
        SSLContext sslContext =SSLContext.getInstance("TLS");
        sslContext.init(null, tmf.getTrustManagers(),null);



//            CertificateFactory cf = CertificateFactory.getInstance("X.509");
//            InputStream caInput = activity.getResources().openRawResource(R.raw.pglsgdkeralagovin);
//
//            Certificate ca = cf.generateCertificate(caInput);
//            caInput.close();
//
//            KeyStore keyStore = KeyStore.getInstance("BKS");
//            keyStore.load(null, null);
//            keyStore.setCertificateEntry("ca", ca);
//
//            String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
//            TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
//            tmf.init(keyStore);
//
//            TrustManager[] wrappedTrustManagers = getWrappedTrustManagers(tmf.getTrustManagers());
//
//            SSLContext sslContext = SSLContext.getInstance("TLS");
//            sslContext.init(null, wrappedTrustManagers, null);

        return sslContext.getSocketFactory();
    }
    public static SSLSocketFactory getSSLSocketFactory()
            throws CertificateException, KeyStoreException, IOException, NoSuchAlgorithmException, KeyManagementException {


        CertificateFactory cf = CertificateFactory.getInstance("X.509");
        InputStream caInput = activity.getResources().openRawResource(R.raw.pglsgdkeralagovin);

        Certificate ca = cf.generateCertificate(caInput);
        caInput.close();

        KeyStore keyStore = KeyStore.getInstance("BKS");
        keyStore.load(null, null);
        keyStore.setCertificateEntry("ca", ca);

        String tmfAlgorithm = TrustManagerFactory.getDefaultAlgorithm();
        TrustManagerFactory tmf = TrustManagerFactory.getInstance(tmfAlgorithm);
        tmf.init(keyStore);

        TrustManager[] wrappedTrustManagers = getWrappedTrustManagers(tmf.getTrustManagers());

        SSLContext sslContext = SSLContext.getInstance("TLS");
        sslContext.init(null, wrappedTrustManagers, null);


            return sslContext.getSocketFactory();
        }

    public static HurlStack hurlStack(){

        HurlStack hurlStack = new HurlStack() {
            @Override
            protected HttpURLConnection createConnection(URL url) throws IOException {
                HttpsURLConnection httpsURLConnection = (HttpsURLConnection) super.createConnection(url);
                try {
                    httpsURLConnection.setSSLSocketFactory(Commonclass.getSSLSocketFactory());
                    httpsURLConnection.setHostnameVerifier(Commonclass.getHostnameVerifier());
                } catch (Exception e) {
System.out.println("Exc"+e);
                }
                return httpsURLConnection;
            }
        };

        return hurlStack;

}
    public static HurlStack hurlStacks(){

        HurlStack hurlStack = new HurlStack() {
            @Override
            protected HttpURLConnection createConnection(URL url) throws IOException {
                HttpsURLConnection httpsURLConnection = (HttpsURLConnection) super.createConnection(url);
                try {
                    httpsURLConnection.setSSLSocketFactory(Commonclass.getSSLSocketFactorys());
                    // httpsURLConnection.setHostnameVerifier(Commonclass.getHostnameVerifier());
                } catch (Exception e) {
                    System.out.println("Exc"+e);
                }
                return httpsURLConnection;
            }
        };

        return hurlStack;

    }
}



// HurlStack hurlStack = Commonclass.hurlStack();