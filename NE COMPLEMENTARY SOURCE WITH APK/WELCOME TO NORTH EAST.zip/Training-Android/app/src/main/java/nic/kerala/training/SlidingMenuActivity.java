package nic.kerala.training;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.MenuItem;

/**
 * Created by asg4.dev13 on 5/25/2017.
 */

public class SlidingMenuActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    DrawerLayout drawer;


    NavigationView navigationView;
    private static final String TAG_Menu = "menu";
    private static final String TAG_Search = "search";
    private static final String TAG_Recycle = "inddai";
    private static final String TAG_map= "indwee";
    private static final String TAG_notification = "indmon";
    private static final String TAG_sql = "indyea";
    private static final String TAG_feed = "feed";
    private static final String TAG_upload= "upload";


    int navItemIndex = 0;

    private static  String CURRENT_TAG = TAG_Menu;

    private String[] activityTitles;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sidemenu);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);



        activityTitles = getResources().getStringArray(R.array.nav_item_activity_titles);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawer.setDrawerListener(toggle);
        toggle.syncState();

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);


        if (savedInstanceState == null) {
            navItemIndex = 0;
            loadHomeFragment();
        }
    }

    private void loadHomeFragment() {


        selectNavMenu();

        // set toolbar title
       // setToolbarTitle();

        // if user select the current navigation menu again, don't do anything
        // just close the navigation drawer
        if (getSupportFragmentManager().findFragmentByTag(CURRENT_TAG) != null) {
            drawer.closeDrawers();

            // show or hide the fab button
            // toggleFab();
            return;
        }
        MainActivity fragment = new MainActivity();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.setCustomAnimations(android.R.anim.fade_in,
                android.R.anim.fade_out);
        fragmentTransaction.replace(R.id.frame, fragment);
        fragmentTransaction.commitAllowingStateLoss();

        //invalidateOptionsMenu();
    }

//    private void setToolbarTitle() {
//
//
//
//        getSupportActionBar().setTitle("");
//
//
//        ImageView img = new ImageView(SlidingMenuActivity.this);
//        img.setImageResource(R.drawable.newhead);
//        ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(ActionBar.LayoutParams.FILL_PARENT,80,Gravity.CENTER);
//        img.setPadding(0,0,20,0);
//        img.setLayoutParams(layoutParams);
//        getSupportActionBar().setCustomView(img);
//
//
//        //getSupportActionBar(). setCustomView(R.layout.activity_title);
//        getSupportActionBar().setDisplayOptions(getSupportActionBar().getDisplayOptions()
//                | ActionBar.DISPLAY_SHOW_CUSTOM);
//    }

    private void selectNavMenu() {
        navigationView.getMenu().getItem(navItemIndex).setChecked(true);
    }

    @Override
    public void onBackPressed() {

        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {


            super.onBackPressed();
        }
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        return super.onOptionsItemSelected(item);
    }

    @SuppressWarnings("StatementWithEmptyBody")

    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();

        if (id == R.id.search) {
            navItemIndex = 0;
            Intent i=new Intent(SlidingMenuActivity.this,SearchActivity.class);
            startActivity(i);

            CURRENT_TAG = TAG_Search;


        }
        else if (id == R.id.Recyclerview) {
            navItemIndex = 1;
            Intent i=new Intent(SlidingMenuActivity.this,RecyclerviewExample.class);
            startActivity(i);
            CURRENT_TAG = TAG_Recycle;


        }
        else if (id == R.id.feed) {
            navItemIndex = 1;
            Intent i=new Intent(SlidingMenuActivity.this,Feedback.class);
            startActivity(i);
            CURRENT_TAG = TAG_feed;


        }
        else if (id == R.id.fileupload) {
            navItemIndex = 1;
            Intent i=new Intent(SlidingMenuActivity.this,FileUpload.class);
            startActivity(i);
            CURRENT_TAG = TAG_upload;


        }
        else if (id == R.id.Map) {
            navItemIndex = 1;
            Intent i=new Intent(SlidingMenuActivity.this,MapsActivity.class);
            startActivity(i);
            CURRENT_TAG = TAG_map;


        }
        else if (id == R.id.sql) {
            navItemIndex = 1;
            Intent i=new Intent(SlidingMenuActivity.this,SqlActivity.class);
            startActivity(i);
            CURRENT_TAG = TAG_sql;


        }
        else if (id == R.id.noti) {
            navItemIndex = 1;
            Intent i=new Intent(SlidingMenuActivity.this,NotificationActivity.class);
            startActivity(i);
            CURRENT_TAG = TAG_notification;


        }




        drawer.closeDrawer(GravityCompat.START);
        loadHomeFragment();
        return true;
    }


}

