package nic.kerala.training;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Created by asg4.dev13 on 6/12/2017.
 */

class ImageAdapter extends BaseAdapter {

    private Context context;

    private int [] imageId={R.drawable.search,R.drawable.ffedback,R.drawable.fileupload,R.drawable.map,R.drawable.notification,R.drawable.sql};
   private String[]mobileValues=new String[]{"Search","Feedback","File Upload","Map","Notification","SQL"};


    // Constructor
    public ImageAdapter(Context c ){
        this.context = c;


    }

    @Override
    public int getCount() {
        return mobileValues.length;
    }

    @Override
    public Object getItem(int position) {
        return mobileValues[position];
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View gridView;

        if (convertView == null) {

            gridView = new View(context);

            // get layout from mobile.xml
            gridView = inflater.inflate(R.layout.activity_custom, null);

            // set value into textview
            TextView textView = (TextView) gridView
                    .findViewById(R.id.grid_item_label);
            textView.setText(mobileValues[position]);

            // set image based on selected text
            ImageView imageView = (ImageView) gridView
                    .findViewById(R.id.grid_item_image);

           imageView.setImageResource(imageId[position]);
            gridView.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View v) {
                    // TODO Auto-generated method stub
                    //  Toast.makeText(context, "You Clicked "+result[position], Toast.LENGTH_LONG).show()
                    if(position==0)
                    {
                        Intent in1 = new Intent(context, SearchActivity.class);
                        context.startActivity(in1);

                    }else if(position==1){
                        Intent in2 = new Intent(context, Feedback.class);
                        context.startActivity(in2);

                    }
                    else if(position==2){
                        Intent in2 = new Intent(context, FileUpload.class);
                        context.startActivity(in2);

                    }else if(position==3){
                        Intent in2 = new Intent(context, MapsActivity.class);
                        context.startActivity(in2);

                    }
                    else if(position==4){
                        Intent in4 = new Intent(context, NotificationActivity.class);
                        context.startActivity(in4);

                    }
                    else{
                        Intent in4 = new Intent(context, SqlActivity.class);
                        context.startActivity(in4);
                        }
                }
            });

        } else {
            gridView = (View) convertView;
        }

        return gridView;
    }

}